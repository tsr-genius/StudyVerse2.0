# StudyVerse 2.0 — Rebuilt Demo

A responsive, single-file study workspace designed for GitHub Pages. The rebuild keeps the existing StudyVerse sections and adds deeper, subject-specific revision content.

## What's included
- A demo lesson for each of 13 subjects, with learning objectives, explanations, vocabulary, a visual summary, a worked example, practice questions, answers, exam tips, and common mistakes.
- Detailed editable notes with ten structured sections: core definition, vocabulary, methods/formulae, diagram/concept map, worked example, practice questions, answers, exam technique, common mistakes, and an active-recall checklist.
- Study-guide demos for all 13 subjects, with chapters, explanations, worked examples, practice and answer reveals.
- Paper colour choices (including lavender, mint, peach, sky, cream and white) and plain, lined, grid, dot-grid, Cornell and graph layouts.
- Browser-local saving and reopening of note content, plus an option to export notes as an HTML file.
- First-visit onboarding for school year, curriculum/syllabus and subjects.
- Plans & Pricing remains in the sidebar, but the bottom-left upgrade/promo card is removed.

## Publish on GitHub Pages
1. Open the repository and replace the existing root `index.html` with this `index.html`.
2. Commit the change to the branch your current GitHub Actions Pages workflow deploys from (usually `main`).
3. Open **Actions** and wait for the Pages workflow to finish successfully.
4. Open the deployment URL from the successful workflow, then hard-refresh the site.

Keep the repository's existing GitHub Actions workflow and Pages settings that are currently working. This package does not change those settings.

## Important demo notes
- Onboarding profile and saved note content are stored in the visitor's browser using localStorage; they are not synced between devices.
- AI / server-dependent features still need a connected backend to perform real AI processing. The lesson, guide, note-generation and study-tool demo flows included here run in the browser.
- The sample educational content is a starting point; compare it with your exact school syllabus, teacher materials and exam-board requirements.
