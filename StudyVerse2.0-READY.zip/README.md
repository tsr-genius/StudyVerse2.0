# StudyVerse 2.0 — onboarding and study-demo update

## Publish
Upload `index.html` to the root of the `main` branch in the `StudyVerse2.0` GitHub repository and commit the change. Keep the currently working GitHub Actions Pages workflow enabled. The zip contains `index.html` and this README at its root.

## Included in this demo build
- First-visit setup for school year, curriculum/syllabus and selected subjects, saved locally in the browser.
- A detailed Physics starter note with vocabulary, formula triangle, worked calculation, graph explanations, practice questions, answers and exam tips.
- Subject-specific detailed sample notes for Physics, Mathematics, Biology and Chemistry; structured study notes for other subjects.
- Demo lessons with subject vocabulary, visual diagrams, worked examples, practice questions, suggested answers and exam tips for Physics, Chemistry, Mathematics, English Language, Biology and French.
- Demo study guide entry points for each listed subject and chapter.
- Paper colour selection preserved when changing page layout, including lavender, mint, peach, sky, cream and white.
- Existing sidebar Plans & Pricing retained without the bottom-left promotional card.

## Prototype limitations
This is a browser-based demo. Profile and notes are stored in local browser storage, not synchronised to a cloud account. Sample content is not guaranteed to match every school syllabus; confirm it against the selected curriculum, coursebook and teacher guidance. Subscription selection is a demonstration and does not process payments.
