# StudyVerse 2.0

A self-contained student study dashboard prototype. Open `index.html` in a browser or publish the file at the root of a GitHub Pages project repository.

## Included demo features
- Dashboard navigation and study workspace
- Editable note editor, templates, paper colours and annotation tools
- Sample revision notes and study guide structure
- Subject-based practice questions with self-marking
- Study planner, material library and demo AI-teacher interface
- Separate Plans & Pricing page with Standard and Pro comparisons

## Important
This is a front-end prototype. Data is stored locally in the browser where implemented. AI responses and subscription selections are demo-only; no real payment processing, account authentication, subscription enforcement, or live AI API is connected.

## GitHub Pages setup
For the project URL `https://tsr-genius.github.io/StudyVerse2.0/`, upload `index.html` to the root of the `StudyVerse2.0` repository and configure Pages to deploy from the branch and folder containing that file (commonly `main` and `/(root)`). Do not rename `index.html` to `README.md`.
