# StudyVerse 2.0 — Study Workspace Demo

**Your material. Your path to mastery.**

StudyVerse is a front-end demonstration of a student learning workspace. It is intentionally in **demo mode**: no API key is needed, and no uploaded file is sent to an AI service. It is designed so you can demonstrate the product idea for Shark Tank without claiming unfinished backend features are live.

## Features to demonstrate

- Cream-and-ivory academic dashboard and detailed sidebar
- Subject selection saved in the browser
- Sample revision notes for Mathematics, English Language, English Literature, Biology, Chemistry, Physics, Computer Science, History, Geography, Business, Economics, French and Spanish
- Create blank editable notes and detailed subject sample notes with definitions, worked examples, practice prompts and exam tips
- Plain, lined, grid, dot-grid, graph and Cornell layouts, plus six paper colours
- Pastel highlighter, marker pen, underline, revision checklist, concept map and formula insertion
- Demo coursebook upload flow (stores the filename and subject in browser local storage; does not read or upload the file contents)
- Practice tests with subject question banks, self-marking, explanations and locally saved progress
- Expanded study-guide chapters with definitions, worked examples, questions, answer guidance, exam tips and common mistakes
- Separate Standard / Pro pricing comparison page (demo selection only; no payment processing)
- Sample AI Notes, Summary, Flashcards and AI Teacher responses
- Fake community posts with local demo likes, replies and reporting interactions, plus profanity filtering on new posts
- Career-path exploration with skill-building suggestions
- University Explorer with example institutions across several countries and a research checklist
- Planner, progress graph, exam preparation and other student dashboard sections

## Run it

### Fastest: open the file

Download the ZIP, extract it, and open `index.html` in a modern browser. Most demo features work without a server. For the best experience, use GitHub Pages or a simple local web server.

### Publish with GitHub Pages

1. Create or open your StudyVerse repository on GitHub.
2. Upload **`index.html` and `README.md`** to the repository's root (the main file list, not inside another folder).
3. Commit the changes.
4. Open **Settings → Pages**.
5. Under the build/deployment source, choose **Deploy from a branch**.
6. Select your main branch (often `main`) and the **`/ (root)`** folder, then save.
7. Wait for GitHub Pages to publish. Open the URL shown in Settings → Pages.

If you previously had a 404, confirm that `index.html` is at the repository root and that Pages is configured to deploy from the same branch and folder.

## Important demo limitations

- **AI is simulated.** The demo responses are prewritten examples selected by subject/topic; they are not produced by a live AI model and are not grounded in uploaded file contents.
- **Uploads are simulated.** The browser records the selected filename and subject only. It does not upload, parse, or store the original file bytes.
- **Community is fake/local.** Example students and posts are fictional. Interactions are only for the current browser demo and are not shared with other visitors.
- **Persistence is local.** Profile, subject choices, chat, sample material metadata and notebooks use browser local storage. Clearing browser data removes them; another device/browser will not see them.
- **University examples are not a ranking or admissions recommendation.** Course availability, entry requirements, fees, scholarships and deadlines must be checked on each institution's official website.
- **Career guidance is exploratory.** It offers general skill suggestions and should not be treated as a prediction of a student's future.

## Future live version

A production version would need a secure backend, an API key stored only as a server-side environment variable, real document parsing, user accounts, database/object storage, moderation/reporting tools and privacy safeguards. Do not put an API key in this static GitHub Pages site or commit secrets to GitHub.


## New in this demo build

The practice builder is local and self-marking. Notes are editable; use “Save notes in this browser” to store note content on the current browser/device. Paper templates and colour swatches apply directly to the editor. The pricing page only records a local plan selection: it does not process payments, create accounts, or securely enforce subscription features. Standard is proposed at RM17/month or RM159/year; Pro is proposed at RM27/month or RM201/year.
