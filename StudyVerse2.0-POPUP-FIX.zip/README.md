# StudyVerse 2.0 — Sidebar Popup Fix

This package removes the persistent StudyVerse plans promo card from the bottom of the sidebar, which was covering part of the app. The separate **Plans & Pricing** sidebar item and pricing comparison page are kept.

## Publish
1. Keep your current working copy as a backup.
2. Replace the repository root `index.html` with this `index.html`.
3. Commit the change to `main`.
4. Keep the working GitHub Actions publishing setup unchanged.
