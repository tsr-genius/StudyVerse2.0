# StudyVerse 2.0 — Enhanced Demo

A self-contained student study workspace prototype. Upload `index.html` to the root of the GitHub Pages repository and keep the existing GitHub Actions publishing workflow that is already working.

## Included
- Detailed sample study notes and guides with definitions, key vocabulary, formulas or answer structures, worked examples, diagrams, practice questions, answer guidance, exam tips and common mistakes.
- Editable notes with Cornell, lined, grid, dot-grid, graph and plain layouts.
- Six paper colours and six annotation colours, plus highlighter, marker, underline, checklist, editable concept diagram, formula prompt and ruler insertion.
- Local-browser note saving.
- Practice tests and progress tracking from the existing demo.
- Separate Plans & Pricing sidebar section with Standard / Pro cards and a comparison table.

## Important demo limitations
- Notes and selections are stored in the current browser using local storage, not synchronised to a user account.
- Sample study material is a prototype, not a live AI service and not guaranteed to match every exam board. Check subject facts against your course materials.
- Plan buttons only record a local demo choice. There is no payment processing, login, or secure feature gating.

## Publish
Replace the repository root `index.html` with this file and commit the change. Keep your currently working GitHub Actions setup unchanged. The ZIP includes `index.html` at its root for easy upload.
